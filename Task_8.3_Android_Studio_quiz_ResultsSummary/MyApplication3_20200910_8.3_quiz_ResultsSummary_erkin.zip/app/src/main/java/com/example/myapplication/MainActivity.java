package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    private Button trueBtn;
    private Button falseBtn;
    private Button showAnswer;
   // private String[] userAnswers;
    private TextView textView;
    private PopupWindow popUp;
    private Question[] questions = {
            new Question(R.string.question1,true),
            new Question(R.string.question2,false),
            new Question(R.string.question3,true),
            new Question(R.string.question4,false),
            new Question(R.string.question5,true)
    };
    private int currentIndex=0;
    HashMap<String, HashMap<Boolean,String>> userAnswers = new HashMap<String, HashMap<Boolean, String>>();

    private String TAG = "Информация о запуске метода: ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG,"Метод onCreate() запущен!");
        setContentView(R.layout.activity_main);
        if (savedInstanceState != null){
            currentIndex = savedInstanceState.getInt("index");
        }
        trueBtn = findViewById(R.id.trueBtn);
        falseBtn= findViewById(R.id.falseBtn);
        showAnswer=findViewById(R.id.showAnswer);
        textView= findViewById(R.id.textView);

        int question = questions[currentIndex].getQuestionTextId();
        textView.setText(question);



        trueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer(true);
                updateQuestion();
            }
        });
        falseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer(false);
                updateQuestion();
            }
        });

        showAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AnswerActivity.class);
                intent.putExtra("answer",questions[currentIndex].isAnswerTrue());
                startActivity(intent);
            }
        });
    }
    private void updateQuestion(){
        currentIndex=(currentIndex+1)%questions.length;
        textView.setText(questions[currentIndex].getQuestionTextId());

        popUp = new PopupWindow(this);
        TextView popupText = new TextView(this);
        Button popupButton = new Button(this);
        LinearLayout popupLayout = new LinearLayout(this);

    ////// Начал пробовать переносить в лэйаут (XML), но сдался

        //RelativeLayout popupLayout = findViewById(R.id.popupLayout);
        //Button popupButton = findViewById(R.id.popupButton);
        //TextView popupText = findViewById(R.id.popupText);

        popupButton.setText("Закрыть");
        popupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popUp.dismiss();
            }
        });

        String textViewFinal = "";

       for (Map.Entry<String, HashMap<Boolean, String>> entry : userAnswers.entrySet()) {
            String k = entry.getKey();
            HashMap v = entry.getValue();
            textViewFinal=textViewFinal
                    +"Вопрос: "+k
                    +"\nВы ответили: "
                    +v.keySet().toString().replaceAll("]$|^\\[", "")
                    +" (Это "+v.values().toString().replaceAll("]$|^\\[", "")
                    +")\n\n";
        }



        LinearLayoutCompat.LayoutParams popupParams = new LinearLayoutCompat.LayoutParams(LinearLayoutCompat.LayoutParams.WRAP_CONTENT, LinearLayoutCompat.LayoutParams.WRAP_CONTENT);
        popupLayout.setOrientation(LinearLayout.VERTICAL);
        popupLayout.setBackgroundColor(Color.parseColor("#EFEFEF"));
        popupText.setText("ВАШИ ОТВЕТЫ\n\n"+textViewFinal);
        popupText.setPadding(40,20,0,0);
        popupText.setTextSize(20);
        popupText.setTextColor(Color.parseColor("#000000"));
        popupButton.setWidth(1000);
        popupButton.setTextSize(20);
        popupButton.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        popupLayout.addView(popupText, popupParams);
        popupLayout.addView(popupButton, popupParams);
        popUp.setContentView(popupLayout);

         if (currentIndex == 0) {
             popupLayout.setVisibility(View.VISIBLE);
            popUp.showAtLocation(popupLayout, Gravity.CENTER, 0, 0);
         }
         popUp.update(0, 0, 1000, 1400);

    }

    private  void checkAnswer(boolean userAnswer){
        if (questions[currentIndex].isAnswerTrue() == userAnswer) {
            Toast.makeText(MainActivity.this, R.string.correct_toast, Toast.LENGTH_SHORT).show();
            userAnswers.put(getString(questions[currentIndex].getQuestionTextId()), new HashMap<Boolean, String>());
            userAnswers.get(getString(questions[currentIndex].getQuestionTextId())).put(userAnswer, getString(R.string.correct_toast));

        }
        else {
            Toast.makeText(MainActivity.this, R.string.incorrect_toast, Toast.LENGTH_SHORT).show();
            userAnswers.put(getString(questions[currentIndex].getQuestionTextId()), new HashMap<Boolean, String>());
            userAnswers.get(getString(questions[currentIndex].getQuestionTextId())).put(userAnswer, getString(R.string.incorrect_toast));
        }
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        Log.d(TAG,"Метод onSaveInstanceState() запущен!!!");
        savedInstanceState.putInt("index",currentIndex);
    }

    @Override
    public void onStart(){
        super.onStart();
        Log.d(TAG,"Метод onStart() запущен");
    }

    @Override
    public void onResume(){
        super.onResume();
        Log.d(TAG,"Метод onResume() запущен");
    }

    @Override
    public void onPause(){
        super.onPause();
        Log.d(TAG,"Метод onPause() запущен");
    }

    @Override
    public void onStop(){
        super.onStop();
        Log.d(TAG,"Метод onStop() запущен");
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(TAG,"Метод onDestroy() запущен");
    }

    @Override
    public void onRestart(){
        super.onRestart();
        Log.d(TAG,"Метод onRestart() запущен");
    }
}